/** Automatically generated file. DO NOT MODIFY */
package com.lia.webview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}