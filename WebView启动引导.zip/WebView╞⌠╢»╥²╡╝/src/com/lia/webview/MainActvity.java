package com.lia.webview;


import android.app.Activity;
import android.os.Bundle;

public class MainActvity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

}
